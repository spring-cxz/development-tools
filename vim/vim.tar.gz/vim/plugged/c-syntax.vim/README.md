C Syntax Highlighting Extension for Vim
===============================================================================

Extract c.vim syntax file from [vim-syntax-extra](https://github.com/justinmk/vim-syntax-extra) to make this separated plugin so that it doesn't have to be bundled with the extra flex & bison syntax files which I found to be a little bit buggy, whereas the Vim built-ins work quite well.


Enhanced C Syntax Highlighting
-------------------------------------------------------------------------------
**Author:** Mikhail Wolfson, Helmut Schellong | [Source](http://www.vim.org/scripts/script.php?script_id=3064)
